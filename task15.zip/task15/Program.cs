﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task15
{
    class Program
    {
        static void Main(string[] args)
        {
            ArithProgression arith = new ArithProgression();
            Random rnd = new Random();
            arith.setStart(rnd.Next(1, 100));
            Console.WriteLine($"Следующее число арифметической прогрессии = {arith.getNext()}");
            arith.reset();
            Console.WriteLine();
            GeomProgression geom = new GeomProgression();
            geom.setStart(rnd.Next(1, 100));
            Console.WriteLine($"Следующее число геометрической прогрессии = {geom.getNext()}");
            geom.reset();
            Console.ReadKey();
            Console.WriteLine();
            Main(args);
        }
    }
}
interface ISeries
{
    void setStart(int x);
    int getNext();
    void reset();
}
class ArithProgression : ISeries
{
    public int x { get; set; }
    public int n { get; set; }
    public int a { get; set; }
    public int getNext()
    {
        Random rnd = new Random();
        n = rnd.Next(1, 10);
        Console.WriteLine($"Шаг равен = {n}");
        return x = x + n;
    }
    public void reset()
    {
        this.x = a;
        Console.WriteLine($"Число сброшено на начало арифметической прогрессии = {x}");
    }

    public void setStart(int x)
    {
        this.x = x;
        this.a = x;
        Console.WriteLine($"Начальное число арифметической прогрессии = {x}");
    }
}
class GeomProgression : ISeries
{
    public int x { get; set; }
    public int n { get; set; }
    public int a { get; set; }
    public int getNext()
    {
        Random rnd = new Random();
        n = rnd.Next(1, 10);
        Console.WriteLine($"Знаменатель равен = {n}");
        return x = x * n;
    }
    public void reset()
    {
        this.x = a;
        Console.WriteLine($"Число сброшено на начало геометрической прогрессии = {x}");
    }

    public void setStart(int x)
    {
        this.x = x;
        this.a = x;
        Console.WriteLine($"Начальное число геометрической прогрессии = {x}");
    }
}